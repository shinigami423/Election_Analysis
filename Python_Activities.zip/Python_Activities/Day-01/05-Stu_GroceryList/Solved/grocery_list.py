# Create a Python list to store your grocery list
grocery_list = ["Milk", "Bread", "Eggs", "Peanut Butter", "Jelly"]

# Print the grocery list
print(grocery_list)

# Change "Peanut Butter" to "Almond Butter" and print out the updated list
grocery_list[3] = "Almond Butter"
print(grocery_list)

# Remove "Jelly" from grocery list and print out the updated list
grocery_list.remove("Jelly")
print(grocery_list)

# Add "Coffee" to grocery list and print the updated list
grocery_list.append("Coffee")
print(grocery_list)